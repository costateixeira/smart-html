
**This content is not yet available. The page will be updated as soon as the content is ready to be shared.**

The FHIR Measure is used to describe the indicator in a computable format. These indicators may be aggregated automatically from the digital tracking tool to populate a digital health management information system (HMIS). 

Measures included in this implementation guide are listed in the [Artifact Index - Measures](artifacts.html)

For the operational descriptions of indicators and references, see <a href="indicators.html">Indicators and Performance Metrics</a> page. 







