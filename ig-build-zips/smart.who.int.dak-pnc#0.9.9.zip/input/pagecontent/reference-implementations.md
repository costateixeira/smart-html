This page includes sample resources that can be leveraged to support the implementation of SMART Guidelines for PNC. Content is for demonstration purposes only.

Additional relevant resources are included in the <a href="references.html">References</a> and <a href="dependencies.html">Dependencies</a>.
 
### Reference applications

### Reference architecture
