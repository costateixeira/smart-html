<?php
function Redirect($url)
{
  header('Location: ' . $url, true, 302);
  exit();
}

$accept = $_SERVER['HTTP_ACCEPT'];
if (strpos($accept, 'application/json+fhir') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-Covid19Product8da0ece0c48e47a9df9e0ad312343219.json2');
elseif (strpos($accept, 'application/fhir+json') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-Covid19Product8da0ece0c48e47a9df9e0ad312343219.json1');
elseif (strpos($accept, 'json') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-Covid19Product8da0ece0c48e47a9df9e0ad312343219.json');
elseif (strpos($accept, 'application/xml+fhir') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-Covid19Product8da0ece0c48e47a9df9e0ad312343219.xml2');
elseif (strpos($accept, 'application/fhir+xml') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-Covid19Product8da0ece0c48e47a9df9e0ad312343219.xml1');
elseif (strpos($accept, 'html') !== false)
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-Covid19Product8da0ece0c48e47a9df9e0ad312343219.html');
else 
  Redirect('http://smart.who.int/pcmt-vaxprequal/v0.1.0/Binary-Covid19Product8da0ece0c48e47a9df9e0ad312343219.xml');
?>
    
You should not be seeing this page. If you do, PHP has failed badly.
